using UnityEngine;

public class ArniRun : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void StartRun() => new GameObject("ARNI RUSH").AddComponent<ArniRun>();

    readonly Transform[] thighs = new Transform[2], calves = new Transform[2], arms = new Transform[2];
    readonly Transform[] barriers = new Transform[8];
    Transform runner;
    int lane;
    float distance, phase;
    bool caught;
    Vector2 press;
    static readonly Color Orange = new Color(1,.34f,.04f), Cloth = new Color(.09f,.08f,.1f);

    Transform Part(Transform parent, PrimitiveType shape, Vector3 position, Vector3 size, Color color)
    {
        var obj = GameObject.CreatePrimitive(shape);
        obj.transform.SetParent(parent,false);
        obj.transform.localPosition = position;
        obj.transform.localScale = size;
        obj.GetComponent<Renderer>().material.color = color;
        return obj.transform;
    }
    Transform Joint(Transform parent, Vector3 position)
    {
        var joint = new GameObject("Joint").transform;
        joint.SetParent(parent,false);
        joint.localPosition = position;
        return joint;
    }
    void Start()
    {
        var cam = Camera.main;
        if (!cam) cam = new GameObject("Camera").AddComponent<Camera>();
        cam.transform.SetPositionAndRotation(new Vector3(0,3.5f,-6.5f),Quaternion.Euler(8,0,0));
        cam.fieldOfView = 65;
        cam.backgroundColor = new Color(.035f,.055f,.12f);
        cam.clearFlags = CameraClearFlags.SolidColor;
        RenderSettings.ambientLight = Color.gray;
        var light = new GameObject("Street light").AddComponent<Light>();
        light.type = LightType.Directional;
        light.transform.rotation = Quaternion.Euler(42,-28,0);
        Part(transform,PrimitiveType.Cube,new Vector3(0,-.15f,45),new Vector3(7,.3f,110),Cloth);
        foreach(float x in new[]{-3.4f,-1f,1f,3.4f})
            Part(transform,PrimitiveType.Cube,new Vector3(x,.01f,45),new Vector3(.04f,.02f,110),Orange);
        runner = Joint(transform,Vector3.zero);
        Part(runner,PrimitiveType.Sphere,new Vector3(0,1.38f,0),new Vector3(.67f,.88f,.46f),Cloth);
        Part(runner,PrimitiveType.Sphere,new Vector3(0,1.76f,-.03f),new Vector3(.49f,.2f,.43f),Orange);
        Part(runner,PrimitiveType.Sphere,new Vector3(0,2.03f,0),Vector3.one*.52f,new Color(.27f,.13f,.07f));
        for(int i=0;i<2;i++)
        {
            float s=2*i-1;
            thighs[i]=Joint(runner,new Vector3(s*.16f,1.03f,0));
            Part(thighs[i],PrimitiveType.Sphere,Vector3.down*.23f,new Vector3(.25f,.53f,.26f),Cloth);
            calves[i]=Joint(thighs[i],Vector3.down*.46f);
            Part(calves[i],PrimitiveType.Sphere,Vector3.down*.22f,new Vector3(.2f,.48f,.22f),Cloth);
            Part(calves[i],PrimitiveType.Sphere,new Vector3(0,-.44f,.07f),new Vector3(.22f,.16f,.38f),Orange);
            arms[i]=Joint(runner,new Vector3(s*.34f,1.64f,0));
            Part(arms[i],PrimitiveType.Sphere,Vector3.down*.18f,new Vector3(.18f,.39f,.18f),Cloth);
            Part(arms[i],PrimitiveType.Sphere,new Vector3(0,-.33f,.15f),new Vector3(.16f,.16f,.34f),Orange);
        }
        for(int i=0;i<barriers.Length;i++)
            barriers[i]=Part(transform,PrimitiveType.Cube,new Vector3(Random.Range(-1,2)*2,.45f,16+i*9),new Vector3(1.25f,.9f,.55f),Orange);
    }
    void OnGUI()
    {
        var e=Event.current;
        if(caught && GUI.Button(new Rect(20,70,190,45),"Ещё раз"))
        {
            distance=0;lane=0;caught=false;runner.localPosition=Vector3.zero;
            for(int i=0;i<barriers.Length;i++) barriers[i].localPosition=new Vector3(Random.Range(-1,2)*2,.45f,16+i*9);
        }
        GUI.Label(new Rect(20,20,370,40),"ARNI RUSH   "+(int)distance+" м   ·   ← → или свайп");
        int move=0;
        if(e.type==EventType.KeyDown) move=e.keyCode==KeyCode.LeftArrow?-1:e.keyCode==KeyCode.RightArrow?1:0;
        if(e.type==EventType.MouseDown) press=e.mousePosition;
        if(e.type==EventType.MouseUp && Mathf.Abs(e.mousePosition.x-press.x)>25) move=e.mousePosition.x>press.x?1:-1;
        if(!caught) lane=Mathf.Clamp(lane+move,-1,1);
    }
    void Update()
    {
        if(caught)return;
        float dt=Time.deltaTime;
        distance+=dt*8;phase+=dt*11;
        runner.localPosition=new Vector3(Mathf.MoveTowards(runner.localPosition.x,lane*2,dt*10),.045f*Mathf.Abs(Mathf.Cos(phase)),0);
        for(int i=0;i<2;i++)
        {
            float step=Mathf.Sin(phase+i*Mathf.PI);
            thighs[i].localRotation=Quaternion.Euler(-36*step,0,0);
            calves[i].localRotation=Quaternion.Euler(8+52*Mathf.Max(0,-step),0,0);
            arms[i].localRotation=Quaternion.Euler(32*step,0,0);
        }
        foreach(var b in barriers)
        {
            var p=b.localPosition;p.z-=8*dt;
            if(Mathf.Abs(p.z)<.55f && Mathf.Abs(p.x-runner.localPosition.x)<.78f)caught=true;
            if(p.z < -5){p.z+=barriers.Length*9;p.x=Random.Range(-1,2)*2;}
            b.localPosition=p;
        }
    }
}
